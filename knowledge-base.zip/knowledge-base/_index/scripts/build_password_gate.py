#!/usr/bin/env python3
"""
静态密码保护页 v3.1
====================
方案 C: 客户端 JS 验证
- 首次访问要求密码
- 验证后存到 sessionStorage（关 tab 失效）
- 密码哈希后存在 JS 里（防止明文泄露）
- ⚠️ 真实安全性: 阻止 90% 闲杂人 / 不防专业用户
"""
import json
import hashlib
from pathlib import Path
from datetime import datetime

SITE = Path("/workspace/output/pilotdeck-site")
PASSWORD_CONFIG = Path("/workspace/knowledge-base/_index/password.json")

# 默认密码
DEFAULT_PASSWORD = "mavis2026"


def get_config():
    if PASSWORD_CONFIG.exists():
        return json.loads(PASSWORD_CONFIG.read_text(encoding="utf-8"))
    return {"enabled": True, "password": DEFAULT_PASSWORD, "hint": "联系管理员"}


def make_password_hash(pw: str) -> str:
    """简单的 SHA256 + salt 哈希"""
    salt = "mavis-kb-2026-salt"  # 静态 salt，足够静态前端
    return hashlib.sha256((salt + pw).encode()).hexdigest()[:24]


def build_gate_html(config: dict) -> str:
    pw_hash = make_password_hash(config["password"])
    enabled = "true" if config.get("enabled", True) else "false"
    hint = config.get("hint", "")

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mavis 知识库 · 访问验证</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  html, body {{ min-height: 100vh; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif; background: #0f1419; color: #e6e9ef; display: flex; align-items: center; justify-content: center; }}
  .gate {{ background: #1a1f29; border: 1px solid #2d3543; border-radius: 12px; padding: 40px 50px; max-width: 420px; width: 90%; text-align: center; box-shadow: 0 10px 40px rgba(0,0,0,0.5); }}
  .logo {{ font-size: 36px; margin-bottom: 8px; }}
  h1 {{ font-size: 22px; margin-bottom: 6px; font-weight: 600; }}
  .sub {{ font-size: 13px; color: #8b95a7; margin-bottom: 28px; }}
  .form {{ display: flex; flex-direction: column; gap: 14px; }}
  input {{ background: #0a0d12; border: 1px solid #2d3543; border-radius: 6px; padding: 12px 16px; color: #e6e9ef; font-size: 15px; outline: none; transition: border 0.15s; }}
  input:focus {{ border-color: #4f9eff; }}
  input.error {{ border-color: #ef4444; }}
  button {{ background: #4f9eff; border: none; border-radius: 6px; padding: 12px; color: white; font-size: 15px; font-weight: 500; cursor: pointer; transition: background 0.15s; }}
  button:hover {{ background: #3a8aef; }}
  button:disabled {{ background: #2d3543; cursor: not-allowed; }}
  .msg {{ font-size: 13px; min-height: 18px; margin-top: 4px; }}
  .msg.err {{ color: #ef4444; }}
  .msg.hint {{ color: #8b95a7; margin-top: 12px; font-size: 12px; }}
  .skip {{ display: none; }}
  .locked .gate {{ display: none; }}
  .locked .skip {{ display: block; }}
</style>
</head>
<body class="{'locked' if not enabled == 'true' else ''}">
  <div class="gate">
    <div class="logo">🔒</div>
    <h1>Mavis 知识库</h1>
    <p class="sub">请输入访问密码</p>
    <form class="form" id="form">
      <input type="password" id="pw" placeholder="密码" autofocus required>
      <button type="submit" id="submit">验证访问</button>
      <div class="msg" id="msg"></div>
    </form>
    {f'<p class="msg hint">提示: {hint}</p>' if hint else ''}
  </div>
  <div class="skip">
    <p>密码已通过验证，请刷新页面或点击 <a href="index.html" style="color:#4f9eff">进入知识库</a></p>
  </div>
<script>
  // v3.1: 静态密码验证
  // 注意: 这是客户端验证，源代码可见 - 仅用于阻止 90% 闲杂人
  const CONFIG = {{
    enabled: {enabled},
    // SHA256(mavis-kb-2026-salt + password)[:24]
    validHashes: ["{pw_hash}"],
    storageKey: "mavis_kb_unlocked_{datetime.now().strftime('%Y%m%d')}"
  }};

  function sha256(s) {{
    // 同步 SHA256 (简单实现)
    function r(n, c) {{
      for (var i = 0; i < c; i++) n = ((n << 1) | (n >>> 31)) & 0xffffffff;
      return n >>> 0;
    }}
    // 用 SubtleCrypto API
    return crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)).then(buf => {{
      return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('').slice(0, 24);
    }});
  }}

  // 检查是否已解锁
  if (sessionStorage.getItem(CONFIG.storageKey) === 'yes') {{
    document.body.classList.add('locked');
  }}

  document.getElementById('form').addEventListener('submit', async (e) => {{
    e.preventDefault();
    const pw = document.getElementById('pw').value;
    const submit = document.getElementById('submit');
    const msg = document.getElementById('msg');

    submit.disabled = true;
    submit.textContent = '验证中...';
    msg.textContent = '';
    msg.className = 'msg';

    try {{
      const hash = await sha256('mavis-kb-2026-salt' + pw);
      if (CONFIG.validHashes.includes(hash)) {{
        sessionStorage.setItem(CONFIG.storageKey, 'yes');
        msg.className = 'msg';
        msg.style.color = '#6ee7b7';
        msg.textContent = '✅ 验证通过，正在跳转...';
        setTimeout(() => {{ window.location.href = 'index.html'; }}, 500);
      }} else {{
        msg.className = 'msg err';
        msg.textContent = '❌ 密码错误';
        document.getElementById('pw').classList.add('error');
        document.getElementById('pw').value = '';
        document.getElementById('pw').focus();
        submit.disabled = false;
        submit.textContent = '验证访问';
      }}
    }} catch (err) {{
      msg.className = 'msg err';
      msg.textContent = '验证失败: ' + err.message;
      submit.disabled = false;
      submit.textContent = '验证访问';
    }}
  }});
</script>
</body>
</html>"""


def main():
    config = get_config()
    SITE.mkdir(parents=True, exist_ok=True)
    gate = build_gate_html(config)
    # 主入口改成 gate.html，index.html 通过 sessionStorage 验证后访问
    (SITE / "gate.html").write_text(gate, encoding="utf-8")
    # 同时也生成 404 等保护
    print(f"✅ gate.html 已生成 ({len(gate)//1024} KB)")
    print(f"   密码: {config['password']} (明文，仅 config 显示)")
    print(f"   哈希: {make_password_hash(config['password'])} (嵌入 gate.html)")
    print(f"   启用: {config.get('enabled', True)}")
    return 0


if __name__ == "__main__":
    import sys
    sys.exit(main())
