# Mavis 多项目知识库追踪框架

> v1.0 · 2026-06-02 建立

## 设计原则

1. **多项目并行** — 一个项目一个目录，统一结构
2. **共享层** — 跨项目数据（竞品池、模板）放在 `_index/`
3. **零迁移成本** — 加新项目 = 复制 `_template/` + 改 `index.json`
4. **Drive 友好** — 文件命名按 `[项目] NN-类别_日期_版本` 约定
5. **可浏览** — `_site/` 部署成静态网站，前端做虚拟目录

## 目录结构

```
knowledge-base/
├── _index/                          # 跨项目共享层
│   ├── projects.json                # 项目注册表（cron 任务读这个）
│   ├── shared-competitors.json      # 共享竞品池
│   └── README.md                    # 本文件
├── projects/                        # 项目集合
│   ├── _template/                   # 新项目模板（只读参考）
│   │   ├── index.json.template
│   │   ├── profile.md.template
│   │   ├── ...
│   ├── pilotdeck/                   # 项目 1：PilotDeck (OpenBMB)
│   │   ├── index.json               # 项目元数据 + cron 配置
│   │   ├── profile.md
│   │   ├── timeline.md
│   │   ├── run-log.md
│   │   ├── tracker-prompt.md
│   │   ├── snapshots/
│   │   ├── briefings/
│   │   │   ├── weekly/
│   │   │   └── monthly/
│   │   ├── competitors/
│   │   ├── templates/
│   │   ├── scripts/
│   │   └── assets/
│   └── <future-project>/            # 未来项目
└── _site/                           # 浏览器端
    ├── index.html                   # 多项目总览
    ├── projects/                    # 单项目详情页
    └── assets/
```

## 命名约定（重要）

### 工作空间（本地）
- 项目目录: `projects/<project-id>/`
- 文件路径见各项目 `index.json`

### Drive（云端上传）
所有通过 `<deliver-assets>` 上传到 Drive 的文件，按以下约定命名：
```
[<project-id>] {NN}-{category}_{name}_{date}_{version}.{ext}
```

**示例**:
- `[PilotDeck] 02-周报_2026-W22.md`
- `[PilotDeck] 02-周报_2026-W22-feishu.txt`
- `[PilotDeck] 03-竞品_T1_2026-06-01.md`
- `[NewProduct] 01-档案_2026-07-01.md`

**类别编号**（与 Drive 文件名 NN 对应）:
| NN | 类别 | 含义 |
|----|------|------|
| 01 | 档案 | profile / 元数据 |
| 02 | 简报 | weekly / monthly / feishu 版本 |
| 03 | 竞品 | tier1 / tier2 / tier3 分析 |
| 04 | 模板 | weekly / monthly 模板 |
| 05 | 配置 | cron prompt / 脚本 / secrets |
| 06 | 日志 | run-log / 错误 |

## 添加新项目

```bash
# 1. 复制模板
cp -r /workspace/knowledge-base/projects/_template/ /workspace/knowledge-base/projects/<new-id>/

# 2. 填入项目元数据
vim /workspace/knowledge-base/projects/<new-id>/index.json

# 3. 在 _index/projects.json 注册
vim /workspace/knowledge-base/_index/projects.json

# 4. （可选）创建 cron 任务
# 用 mavis cron create，prompt 路径指向 projects/<new-id>/tracker-prompt.md

# 5. 重新部署知识库浏览器
# 用 website_deploy 部署 _site/ 目录
```

## 跨项目共享

### 竞品池
`_index/shared-competitors.json` 集中维护所有项目可能用到的竞品信息。新项目引用而非复制：

```json
{
  "competitors_tier1": ["claude-cowork", "skywork", "openclaw"]
}
```

这避免每个项目的竞品文档重复维护，**一处更新，全员受益**。

## Cron 任务设计

每个项目可以独立配 cron 任务。任务 prompt 必须遵循以下范式：

1. **读 `_index/projects.json`** — 自动发现所有 active 项目
2. **对每个项目执行追踪流程** — 复用同样的 prompt 模板
3. **统一推送** — 所有项目简报可推到同一个飞书群（带项目前缀区分）

**示例 prompt 路径**:
- `projects/pilotdeck/tracker-prompt.md`
- `projects/<new-id>/tracker-prompt.md`

## 知识库浏览器（_site/）

`website_deploy` 工具把 `_site/` 部署成静态网站，提供：
- 跨项目总览（首页）
- 单项目详情（带侧边栏导航）
- 实时数据展示（嵌入 JSON）
- 全文本搜索（前端 JS）

**部署命令**:
```
website_deploy({ path: "/workspace/knowledge-base/_site/", project_name: "Mavis 知识库" })
```

每次内容更新需重新部署（持续集成思路：内容变化 → 重新生成 HTML → 重新部署）。

## 已知限制 & 待办

- ⚠️ **Drive 无 create_folder 命令** —— 文件只能平铺，靠命名前缀分类
- ⚠️ **website_deploy 每次内容更新需重新部署** —— 自动化部署 pipeline 待建设
- 🔜 **多项目并行 cron** —— 当前各项目 cron 独立触发，未来可合并
- 🔜 **跨项目数据共享 API** —— 让 cron 任务能查询其他项目的数据
- 🔜 **前端搜索** —— 当前 HTML 是手写静态页，未来用 MiniMax 生成更智能的搜索

## 变更日志

- 2026-06-02: v1.0 建立（从单项目 PilotDeck 升级到多项目框架）
