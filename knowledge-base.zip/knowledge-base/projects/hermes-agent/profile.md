# Hermes Agent 项目档案

> 最后更新：2026-06-02 10:10 (Asia/Shanghai)  
> 追踪者：Mavis  
> 数据源：GitHub REST API + 媒体资料

## 一句话定位

The only agent with a built-in learning loop - 会自我进化的个人 AI 助理

## 项目元数据

| 字段 | 值 |
|------|-----|
| 项目 ID | `hermes-agent` |
| 名称 | Hermes Agent |
| 厂商 | NousResearch |
| 类别 | Self-Evolving Personal Agent |
| License | MIT |
| 主语言 | Python |
| 官网 | https://nousresearch.ai (推测) |
| 仓库 | [https://github.com/NousResearch/hermes-agent](https://github.com/NousResearch/hermes-agent) |

## 关键数据（2026-06-02 实时）

| Stars | **176,065** |
| Forks | 30,047 |
| Watchers | 176,065 |
| Open Issues | 16,290 |
| License | MIT |
| 主语言 | Python |
| Size | 278.5 MB |
| 仓库创建 | 2025-07-22 |
| 最近 push | 2026-06-02 |
| Homepage | https://hermes-agent.nousresearch.com |

## 核心能力

- **自我进化闭环: 任务→技能创建→技能优化→跨会话调用** - 自我进化闭环: 任务→技能创建→技能优化→跨会话调用
- **持久记忆双文件: MEMORY.md + USER.md** - 持久记忆双文件: MEMORY.md + USER.md
- **SQLite FTS5 全文搜索** - SQLite FTS5 全文搜索
- **40+ 工具 + 105 内置技能** - 40+ 工具 + 105 内置技能
- **12+ 消息平台** - 12+ 消息平台 (Telegram/Discord/Slack/微信/QQ/飞书/钉钉等)
- **v0.11.0 React/Ink TUI 全面重写** - v0.11.0 React/Ink TUI 全面重写
- **5 大推理路径** - 5 大推理路径 (NVIDIA NIM/Arcee AI/Step Plan 等)
- **AWS Bedrock 原生支持** - AWS Bedrock 原生支持
- **Skills Hub 7 源 + 4 级信任模型** - Skills Hub 7 源 + 4 级信任模型
- **6 终端后端** - 6 终端后端 (local/docker/ssh/daytona/singularity/modal)

## 监控优先级

### 高优先级
- v0.x 快速版本迭代
- Nous Portal 模型集成
- 自我进化机制实际效果

### 中优先级
- Skills Hub 生态扩张
- TUI 体验优化
- MCP 双向支持

### 低优先级
- GitHub 16k open issues 关闭率

## T1 竞品（参考）

openclaw, pilotdeck, deer-flow, openhuman

## 更新规则

- 每周一 (周报触发时): 拉取 GitHub 指标、commit、PR 数据，刷新本文件
- 每月最后一日 (月报触发时): 重点章节做版本对比，输出演进路线
- 重大事件: 立即追加到 `timeline.md`
