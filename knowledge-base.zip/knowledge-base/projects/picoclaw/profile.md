# PicoClaw 项目档案

> 最后更新：2026-06-02 10:10 (Asia/Shanghai)  
> 追踪者：Mavis  
> 数据源：GitHub REST API + 媒体资料

## 一句话定位

在 10 美元 RISC-V 芯片上跑的 AI 智能体 - 极致轻量

## 项目元数据

| 字段 | 值 |
|------|-----|
| 项目 ID | `picoclaw` |
| 名称 | PicoClaw |
| 厂商 | Sipeed (矽速科技) |
| 类别 | Edge AI Agent |
| License | MIT (推测) |
| 主语言 | Go |
| 官网 | https://github.com/sipeed/picoclaw |
| 仓库 | [https://github.com/sipeed/picoclaw](https://github.com/sipeed/picoclaw) |

## 关键数据（2026-06-02 实时）

| Stars | **29,259** |
| Forks | 4,191 |
| Watchers | 29,259 |
| Open Issues | 81 |
| License | MIT |
| 主语言 | Go |
| Size | 38.8 MB |
| 仓库创建 | 2026-02-04 |
| 最近 push | 2026-06-02 |
| Homepage | https://picoclaw.io |

## 核心能力

- **内存 < 10MB，启动 < 1秒** - 内存 < 10MB，启动 < 1秒
- **0.6GHz 单核流畅运行** - 0.6GHz 单核流畅运行
- **RISC-V / ARM / x86 全平台** - RISC-V / ARM / x86 全平台
- **联网搜索 + 文件系统 + 长短期记忆 + 定时任务 + 子 Agent** - 联网搜索 + 文件系统 + 长短期记忆 + 定时任务 + 子 Agent
- **Telegram / Discord 接入** - Telegram / Discord 接入
- **OpenAI 兼容 LLM 接入** - OpenAI 兼容 LLM 接入
- **单一二进制部署** - 单一二进制部署

## 监控优先级

### 高优先级
- 嵌入式场景采用
- 10 美元硬件适配
- 跨架构稳定性

### 中优先级
- Skills 生态
- Telegram/Discord 集成

### 低优先级
- GitHub stars 增长

## T1 竞品（参考）

openclaw, openhuman, pilotdeck

## 更新规则

- 每周一 (周报触发时): 拉取 GitHub 指标、commit、PR 数据，刷新本文件
- 每月最后一日 (月报触发时): 重点章节做版本对比，输出演进路线
- 重大事件: 立即追加到 `timeline.md`
