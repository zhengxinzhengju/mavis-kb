# OpenClaw 项目档案

> 最后更新：2026-06-02 09:50 (Asia/Shanghai)  
> 追踪者：Mavis (root session 404453968618295)  
> 数据源：GitHub REST API (api.github.com/repos/openclaw/openclaw)

## 一句话定位

**Your own personal AI assistant. Any OS. Any Platform. The lobster way. 🦞** — 本地优先的通用 AI 助手，可通过 WhatsApp/Telegram/Discord/Slack/Signal/iMessage 等多平台接入。

## 关键数据（2026-06-02 GitHub API 实时）

| 指标 | 数值 | 备注 |
|------|------|------|
| **GitHub Stars** | **376,079** | ⭐ 史上最高 Star 软件项目（超越 React） |
| Forks | 78,544 | |
| Watchers | 376,079 | |
| Open Issues | 7,059 | 社区高度活跃 |
| Contributors | 50+ (Top 3 占 95%+) | |
| 最近 push | 2026-06-02 01:48 UTC | 2 小时前 |
| 仓库创建 | 2025-11-24 | 6 个多月 |
| 主语言 | TypeScript | |
| Size | 1.49 GB | 大型 monorepo |
| License | Other (NOASSERTION) | 自定义许可 |
| 主页 | https://openclaw.ai | |
| Discussions | ❌ 未启用 | |
| Wiki | ❌ 未启用 | |

## 贡献者排行（Top 5）

| 排名 | 用户 | Commits | 占比 |
|------|------|---------|------|
| 1 | steipete (Peter Steinberger) | 31,495 | **70.0%** |
| 2 | vincentkoc | 6,830 | 15.2% |
| 3 | shakkernerd | 3,236 | 7.2% |
| 4 | obviyus | 1,474 | 3.3% |
| 5 | Takhoffman | 834 | 1.9% |

⚠️ **极度单点风险**: Top 1 占 70% — 项目命运几乎完全依赖 Peter Steinberger 一人

## Release 节奏（极快）

2026-06-01 单日发布：
- `v2026.6.1-beta.2`
- `v2026.6.1-beta.1`
- `v2026.5.31-beta.4`

**每天 4-5 个 release** — 工程化极度活跃，但也是"快速但不稳"的信号

## 最近 PR（最近 24h）

| PR # | 标题 | 作者 | 日期 |
|------|------|------|------|
| #89246 | Revert "fix(memory): warn on gateway watcher FD risk" | steipete | 2026-06-01 |
| #89220 | fix(agents): avoid duplicate generated media fallback | steipete | 2026-06-01 |
| #89212 | test: reset gateway timers at test boundaries | steipete | 2026-06-01 |
| #89188 | fix(memory-core): reduce Linux watcher fan-out | steipete | 2026-06-01 |
| #89185 | fix(memory): warn on gateway watcher FD risk | steipete | 2026-06-01 |
| #89181 | fix(agents): dispatch auth failures by type | steipete | 2026-06-01 |

## 核心架构

- **Local Gateway**: 本地 Node.js 服务 + 消息应用桥接
- **多平台接入**: WhatsApp / Telegram / Discord / Slack / Signal / iMessage
- **心跳系统**: Cron 定时主动推送
- **BYO-Key 模式**: 模型无关 (OpenAI / Anthropic / Ollama / DeepSeek)
- **Skills 生态**: AgentSkills 插件系统
- **v2.18** (2026-05-06) 重大更新：ContextEngine + Active Memory + OTEL

## 历史里程碑

- 2025-11-24: 仓库创建
- 2026-01-25: 公开首发 (Clawdbot)
- 商标争议: 改名 Clawdbot → Moltbot → 最终定名 OpenClaw
- 2026-01-25: 24h 达成 9k stars (史上最快首发)
- 2026-01-28: 72h 60k stars
- 2026-02-XX: 100k stars (1 个月内)
- 2026-03-XX: 250k+ stars (超越 React)
- 2026-04-25: v2026.4.24 — DeepSeek V4 Flash 设为新默认模型
- 2026-05-06: v2.18 — ContextEngine + Active Memory + OTEL
- 2026-06-01: 单日 3+ releases
- 2026-06-02: **376,079 stars** （持续增长中）

## 安全风险

- ⚠️ **ClawJacked CVE 8.8** (已修复，但暴露了完整系统访问的攻击面)
- ⚠️ $CLAWD 加密骗局 (1600 万美元市值归零)
- ⚠️ 完整 root 访问 = 巨大安全责任

## 衍生版本

- **QClaw** (腾讯): 原生支持微信/QQ + IM 生态接入

## 与 PilotDeck 对比

| 维度 | OpenClaw | PilotDeck |
|------|----------|-----------|
| 规模 | **376k stars, 70k+ forks** | 2.6k stars, 246 forks |
| 定位 | 通用 Agent (聊天+执行) | 生产力 OS (项目级) |
| 接入 | 消息应用 (WhatsApp 等) | Web/桌面/CLI/IM (飞书/企微) |
| 项目隔离 | 无 WorkSpace 概念 | **WorkSpace 三层** |
| 记忆 | 本地 Markdown 文件 | **白盒 + Dream + Rollback** |
| 路由 | 无 | **子 Agent 智能路由** |
| 主动性 | Cron 心跳 | **Always-on + 主动发现** |
| Skills | AgentSkills 生态 | WorkSpace 装 |
| 风险 | 全系统访问、ClawJacked | AGPL-3.0、商业风险 |
| 现状 | **工程化极度活跃，每天 4-5 release** | 媒体爆红期 |

**核心定位差异**:
- OpenClaw: 通用 Agent 平台，"做事的 AI"
- PilotDeck: 项目级生产力 OS，"管项目的 AI"

## 监控优先级

| 优先级 | 监控项 |
|--------|--------|
| 🔴 高 | 安全漏洞 (CVE/ClawJacked 系列) |
| 🔴 高 | Release 节奏 (日均 4+) |
| 🔴 高 | 核心 maintainer 动态 (steipete) |
| 🟡 中 | Skills 生态扩张 |
| 🟡 中 | 新模型集成 (默认模型切换) |
| 🟡 中 | 国内衍生版本 (QClaw) |
| 🟢 低 | Issues 关闭率 |
| 🟢 低 | 新 contributors 增长 |

## 更新规则

- 每周一: 拉取 GitHub 数据、PR、release 节奏，写周报
- 每月最后一日: 重点关注安全事件、社区健康度，写月报
- 重大事件: 立即追加 timeline（如 CVE、steipete 重大决策）
