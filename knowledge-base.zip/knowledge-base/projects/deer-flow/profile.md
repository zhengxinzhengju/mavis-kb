# DeerFlow 项目档案

> 最后更新：2026-06-02 10:10 (Asia/Shanghai)  
> 追踪者：Mavis  
> 数据源：GitHub REST API + 媒体资料

## 一句话定位

Deep Exploration and Efficient Research Flow - 字节跳动开源的长时程 SuperAgent 框架

## 项目元数据

| 字段 | 值 |
|------|-----|
| 项目 ID | `deer-flow` |
| 名称 | DeerFlow |
| 厂商 | ByteDance (字节跳动) |
| 类别 | Super Agent Framework |
| License | Apache-2.0 |
| 主语言 | Python |
| 官网 | https://deerflow.tech |
| 仓库 | [https://github.com/bytedance/deer-flow](https://github.com/bytedance/deer-flow) |

## 关键数据（2026-06-02 实时）

| Stars | **70,212** |
| Forks | 9,480 |
| Watchers | 70,212 |
| Open Issues | 919 |
| License | MIT |
| 主语言 | Python |
| Size | 36.1 MB |
| 仓库创建 | 2025-05-07 |
| 最近 push | 2026-06-02 |
| Homepage | https://deerflow.tech |

## 核心能力

- **LangGraph 1.0 + LangChain 重构 v2.0** - LangGraph 1.0 + LangChain 重构 v2.0
- **Lead Agent + Sub-Agent 动态生成与并行执行** - Lead Agent + Sub-Agent 动态生成与并行执行
- **Docker 沙箱隔离** - Docker 沙箱隔离 (AioSandboxProvider/Local/K8s)
- **Markdown Skills 系统** - Markdown Skills 系统 (npx skills add)
- **11 层中间件链** - 11 层中间件链
- **分层记忆: Thread Memory + Context Summarization + External Storage** - 分层记忆: Thread Memory + Context Summarization + External Storage
- **断点续跑** - 断点续跑 (Checkpoint & Resume)
- **多 IM 接入: Telegram/Slack/飞书/钉钉** - 多 IM 接入: Telegram/Slack/飞书/钉钉

## 监控优先级

### 高优先级
- 社区热度 (月增 31K stars)
- v2.x 重大版本演进
- 字节跳动内部资源投入

### 中优先级
- Skills 生态扩张
- Sub-Agent 稳定性
- MCP 集成

### 低优先级
- Issues 关闭率

## T1 竞品（参考）

openclaw, pilotdeck, hermes-agent, openhuman, qwenpaw

## 更新规则

- 每周一 (周报触发时): 拉取 GitHub 指标、commit、PR 数据，刷新本文件
- 每月最后一日 (月报触发时): 重点章节做版本对比，输出演进路线
- 重大事件: 立即追加到 `timeline.md`
