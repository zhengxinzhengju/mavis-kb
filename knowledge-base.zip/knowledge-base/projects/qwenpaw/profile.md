# QwenPaw 项目档案

> 最后更新：2026-06-02 10:10 (Asia/Shanghai)  
> 追踪者：Mavis  
> 数据源：GitHub REST API + 媒体资料

## 一句话定位

Qwen Personal Agent Workstation - 通义千问生态的桌面 Agent 平台（前 CoPaw）

## 项目元数据

| 字段 | 值 |
|------|-----|
| 项目 ID | `qwenpaw` |
| 名称 | QwenPaw |
| 厂商 | Alibaba (阿里) / AgentScope |
| 类别 | Desktop Agent |
| License | Apache-2.0 (推测) |
| 主语言 | Python |
| 官网 | https://qwenpaw.com (待确认) |
| 仓库 | [https://github.com/agentscope-ai/QwenPaw](https://github.com/agentscope-ai/QwenPaw) |

## 关键数据（2026-06-02 实时）

| Stars | **17,147** |
| Forks | 2,540 |
| Watchers | 17,147 |
| Open Issues | 889 |
| License | Apache-2.0 |
| 主语言 | Python |
| Size | 79.7 MB |
| 仓库创建 | 2026-02-24 |
| 最近 push | 2026-06-01 |
| Homepage | http://qwenpaw.agentscope.io/ |

## 核心能力

- **2026-04-12 由 CoPaw 正式更名 QwenPaw，发布 1.1.0** - 2026-04-12 由 CoPaw 正式更名 QwenPaw，发布 1.1.0
- **深度绑定 Qwen 系列模型** - 深度绑定 Qwen 系列模型 (Qwen-2.5/CodeQwen)
- **多平台接入: 钉钉/飞书/QQ/Discord/iMessage** - 多平台接入: 钉钉/飞书/QQ/Discord/iMessage
- **本地一键部署 + 云端一键部署** - 本地一键部署 + 云端一键部署
- **支持本地模型挂载** - 支持本地模型挂载
- **端云结合** - 端云结合 (本地模型增强 + 云端千问协同)
- **Multi-Agent 协作探索** - Multi-Agent 协作探索
- **安全升级: 隐私 + 端侧推理** - 安全升级: 隐私 + 端侧推理

## 监控优先级

### 高优先级
- Qwen 生态整合进展
- 阿里云资源投入
- 用户量增长

### 中优先级
- 多平台接入稳定性
- Skills 生态
- Multi-Agent 能力

### 低优先级
- GitHub Issues 关闭率

## T1 竞品（参考）

openclaw, pilotdeck, hermes-agent, openhuman, picoclaw

## 更新规则

- 每周一 (周报触发时): 拉取 GitHub 指标、commit、PR 数据，刷新本文件
- 每月最后一日 (月报触发时): 重点章节做版本对比，输出演进路线
- 重大事件: 立即追加到 `timeline.md`
