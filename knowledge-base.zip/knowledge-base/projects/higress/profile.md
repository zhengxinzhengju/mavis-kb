# Higress 项目档案

> 最后更新：2026-06-02 10:10 (Asia/Shanghai)  
> 追踪者：Mavis  
> 数据源：GitHub REST API + 媒体资料

## 一句话定位

Next-generation Cloud Native Gateway - 阿里开源的三合一网关

## 项目元数据

| 字段 | 值 |
|------|-----|
| 项目 ID | `higress` |
| 名称 | Higress |
| 厂商 | Alibaba (阿里云) |
| 类别 | Cloud Native API Gateway |
| License | Apache-2.0 |
| 主语言 | Go (Envoy base) |
| 官网 | https://higress.io |
| 仓库 | [https://github.com/higress-group/higress](https://github.com/higress-group/higress) |

## 关键数据（2026-06-02 实时）

| Stars | **8,535** |
| Forks | 1,136 |
| Watchers | 8,535 |
| Open Issues | 778 |
| License | Apache-2.0 |
| 主语言 | Go |
| Size | 40.8 MB |
| 仓库创建 | 2022-10-27 |
| 最近 push | 2026-06-01 |
| Homepage | https://higress.ai |

## 核心能力

- **基于 Istio + Envoy** - 基于 Istio + Envoy
- **Ingress / Gateway API 标准** - Ingress / Gateway API 标准
- **毫秒级配置热更新** - 毫秒级配置热更新 (无 reload)
- **Wasm/Lua/进程外插件** - Wasm/Lua/进程外插件
- **Nginx Ingress 注解平滑迁移** - Nginx Ingress 注解平滑迁移
- **HTTP 转 Dubbo 协议** - HTTP 转 Dubbo 协议
- **深度集成 Nacos + Sentinel** - 深度集成 Nacos + Sentinel
- **Dify 插件** - Dify 插件 (AI 网关能力)
- **多 K8s 集群支持** - 多 K8s 集群支持

## 监控优先级

### 高优先级
- 云原生采用率
- AI 网关场景渗透
- 插件生态

### 中优先级
- 性能 vs Envoy/Traefik
- Wasm 生态

### 低优先级
- Issues 关闭率

## T1 竞品（参考）

(无直接对标，T2 框架相关)

## 更新规则

- 每周一 (周报触发时): 拉取 GitHub 指标、commit、PR 数据，刷新本文件
- 每月最后一日 (月报触发时): 重点章节做版本对比，输出演进路线
- 重大事件: 立即追加到 `timeline.md`
