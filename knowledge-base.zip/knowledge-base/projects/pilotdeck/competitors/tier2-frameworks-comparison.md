# T2 Agent 框架层对比

> 这些是 Agent 框架/SDK，不直接对标 PilotDeck 但 PilotDeck 内部可能集成或互操作。  
> **最后更新**: 2026-06-01 18:05

## 框架总览

| 框架 | 厂商 | Stars | 架构风格 | 多语言 | MCP | Skills |
|------|------|-------|---------|--------|-----|--------|
| LangGraph | LangChain | 31k | 图/状态机 | Py + JS | ⚠️ 适配器 | ⚠️ 子图 |
| CrewAI | CrewAI Inc. | 50.4k | 角色组队 | Py | ✅ 原生 | ✅ 一等公民 |
| Claude Agent SDK | Anthropic | 6.6k | 自主工具循环 | Py + TS | ✅ 最深 | ✅ 一等公民 |
| OpenAI Agents SDK | OpenAI | 25.7k | 轻量 Provider 无关 | Py + JS | ✅ 原生 | ⚠️ 基础 |
| MS Agent Framework | Microsoft | 10k | 图工作流 + 分层 | Py + .NET | ⚠️ 集成中 | ⚠️ 基础 |
| Google ADK | Google | 19.4k | 代码优先 + 层级 | Py + Java + Go | ✅ 原生 | ⭐ 建设中 |

## 关键观察

### 2026 年框架格局已基本定型
- 早期百花齐放（AutoGPT/BabyAGI/CAMEL/MetaGPT）→ 主流 6 框架收敛
- MS Agent Framework 统一了 AutoGen + Semantic Kernel（AutoGen 进入维护）
- Google ADK 是唯一 3 语言一致的

### Skills 系统的两极分化
- **一等公民**: CrewAI, Claude Agent SDK（都有专门仓库和 Marketplace）
- **建设中**: Google ADK（Skill Registry 刚合并）
- **基础/无**: OpenAI Agents SDK, MS Agent Framework, LangGraph

### MCP 集成深度
- **最深的**: Claude Agent SDK（支持进程内 SDK MCP Server，零额外进程）
- **原生**: CrewAI, OpenAI SDK, Google ADK
- **适配器**: LangGraph（通过 langchain-mcp-adapters）

## PilotDeck 的位置

PilotDeck 不是一个"框架"——它是一个**面向终端用户的 Agent OS**。框架是给开发者用的，OS 是给最终用户用的。

但 PilotDeck 内部：
- 路由层可以参考 LangGraph 的图状态机
- Skills 系统可以参考 CrewAI 的 Markdown + Marketplace 设计
- MCP 集成对标 Claude Agent SDK 的深度

## 监控建议

- **每周**: 只看是否有重大 release（> 1k star 增长）
- **每月**: 做一次框架生态对比，输出"PilotDeck 是否落后于框架层新特性"的判断

## 新增追踪对象

考虑到 T2 框架的重要性在上升，建议月报中加入：

| 框架 | 监控指标 |
|------|---------|
| LangGraph | stars 增长、v1.0 进展、图状态机新特性 |
| CrewAI | Skills 仓库增长、v1.x 路线图 |
| Claude Agent SDK | MCP 新能力、Skills Marketplace 扩张 |
| OpenAI Agents SDK | Sandbox Agents 进展、多 LLM 支持 |
| MS Agent Framework | .NET 生态整合、Foundry Toolboxes |
| Google ADK | Skill Registry GA 进度、三语言一致性 |
