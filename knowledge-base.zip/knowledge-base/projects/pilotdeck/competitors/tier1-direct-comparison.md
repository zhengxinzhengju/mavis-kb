# T1 直接竞品对比 — Agent OS / 桌面 Agent

> **最后更新**: 2026-06-01 18:05 (Asia/Shanghai)  
> 覆盖范围: 桌面 Agent / 项目级 OS / 本地优先 Agent  
> 数据来源: 各产品官网、官方文档、媒体报道、GitHub API

## 竞品全景

| 竞品 | 厂商 | 形态 | 首发时间 | 当前规模 | License | 平台 |
|------|------|------|---------|---------|---------|------|
| **Claude Cowork** | Anthropic | 桌面应用 (Claude Desktop) | 2026-01-13 | 商业，订阅 $20-200/月 | 闭源 | macOS (Windows 即将) |
| **Skywork 桌面版** | 昆仑天工 (昆仑万维) | Windows 桌面应用 | 2026-02-04 | 商业，Basic/Plus 订阅 | 闭源 | Windows 优先 |
| **BitFun CoWork** | GCWing (个人) | 开源 IDE + CoWork 模式 | 2026-02 (CoWork) | v0.1.0 早期 | **MIT** | Windows / macOS |
| **OpenClaw** | Peter Steinberger (NousResearch) | 本地 Node.js 服务 | 2026-01-25 | 28 万+ Stars, GitHub #1 | (待查) | 跨平台 |
| **QoderWork** | 阿里 | 桌面 Agent | 2026-01-30 消息 | 内部消息阶段 | 闭源 | 未知 |
| **MiniMax Agent 桌面版** | MiniMax | 桌面应用 | 2026-02-03 上线 | 商业 | 闭源 | 跨平台 |
| **阶跃 AI 桌面伙伴** | 阶跃星辰 | 桌面应用 | 2025-09 | 商业 | 闭源 | 跨平台 |

## 1. Claude Cowork (Anthropic)

### 关键事实
- **首发**: 2026-01-13，Claude Max 订阅 ($100-200/月) 独占
- **2026-02 降价**: 下放至 Pro 档 ($20/月)
- **平台**: 仅 macOS (Windows 在规划中)
- **核心代码**: 几乎全部由 Claude 自己生成，1.5 周从需求到上线
- **开发模式**: 每位开发者同时管理 3-8 个 Claude 窗口指挥其工作

### 核心能力
- 指定本地文件夹 → Claude 直接读/写/创建文件
- 任务队列 + 并行处理，"给同事留言"的体验
- Skills 系统（Markdown 写的工作流，1 次创建无限调用）
- 连接器：Asana、Notion、PayPal 等
- Chrome 扩展

### 生态布局
- 2026-01-30 发布 `knowledge-work-plugins` 开源仓库
- **18 个岗位插件**: 销售、产品、财务、法务、HR、运营、设计师、工程师……
- 9.7k+ stars, 1k+ forks
- TechCrunch、CNBC、CNN 同步报道

### 战略意图
- Claude Code → Cowork = 开发者工具 → 全员生产力工具
- 把 Skills Marketplace 打造成"AI 时代的 App Store"
- 对标微软 Copilot 的生产力平台战略

### 与 PilotDeck 对比
| 维度 | Claude Cowork | PilotDeck |
|------|---------------|-----------|
| 平台 | 仅 macOS | macOS/Linux/Windows/Docker |
| 项目隔离 | Projects (文件夹+规则) | **WorkSpace 三层 (FS+Memory+Skills)** |
| 记忆 | 黑盒 | **白盒可编辑+回滚** |
| 主动性 | 用户触发 | **Always-on 24h** |
| 路由 | 手动选模型 | **子 Agent 级别智能路由** |
| License | 闭源 | AGPL-3.0 (企业风险) |
| 成本 | 订阅 $20-200/月 | BYO-Key + 智能路由省 70% |

---

## 2. Skywork 桌面版 (昆仑天工)

### 关键事实
- **首发**: 2026-02-04，全球发布
- **母公司**: 昆仑万维 (上市公司)
- **战略**: "Windows 党的胜利" — 填补 Windows 阵营空白
- **商业模式**: 付费订阅 (Basic / Plus 两档)
- **2025-05 起点**: Skywork Super Agents 网页版发布

### 核心能力
- **三模型自由切换**: Claude Opus 4.5 / Sonnet 4.5 / Gemini 3 Pro + auto 智能推荐
- **100+ 内置 Skills**: Office 三件套、网页生成、图像生成、视频生成
- **本地虚拟机隔离**: 文件不出本机
- **执行前确认**: 操作清单 → 用户确认 → 执行
- **多任务并行**: 同时处理跨文件、跨格式任务

### 性能宣传 (官方)
- 图像/视频质量 "超越 Claude Cowork"
- "auto" 模式下任务执行速度超越 Claude Cowork
- 实测表现：2 分钟不到生成可交互的 AI 峰会官网

### 战略意图
- 对标 Claude Cowork + OpenClaw，主打 Windows 生态
- "AI 新榜" 等媒体评测已经把它定位为 "Windows 版 Claude Cowork"
- "OS 级同事" 的产品定位 = 操作系统级 AI 助手

### 与 PilotDeck 对比
| 维度 | Skywork 桌面版 | PilotDeck |
|------|----------------|-----------|
| 平台 | Windows 优先 | 全平台 |
| 模型 | 三模型 + auto | 全 OpenAI 兼容 + 火山方舟等国内 |
| Skills | 100+ 内置 | WorkSpace 内装（少但可装） |
| 记忆 | 不可见 | 白盒可编辑 |
| 路由 | auto 模式 | **子 Agent 级别 + 自定义规则** |
| 隔离 | 本地 VM | **项目级三层隔离** |
| 主动性 | 用户触发 | **Always-on 24h** |
| License | 闭源 | AGPL-3.0 |
| 成本 | 订阅 | BYO-Key |

---

## 3. BitFun + BitFun CoWork (个人开发者 GCWing)

### 关键事实
- **主体首发**: 2026-02-18 公布，2026-03-11 正式发布
- **CoWork 模式**: 2026-02 推出
- **License**: **MIT** (vs PilotDeck 的 AGPL-3.0) — 商业友好
- **当前状态**: v0.1.0 早期版本
- **技术栈**: Rust + TypeScript + Tauri (极致轻量)

### 核心能力
- **4 大工作模式**: Agentic / Plan / Debug / Review
- **Agent 体系**: 个人助理 / Code Agent / CoWork Agent / 自定义 Agent
- **MCP 协议**: 完整支持
- **Skills**: 自动读取 Cursor / Claude Code / Codex 配置
- **代码本地运行 + 全链路可审计** (97% 代码由 Vibe Coding 生成)

### 与 PilotDeck 对比
| 维度 | BitFun CoWork | PilotDeck |
|------|---------------|-----------|
| 定位 | IDE + CoWork (编程为主) | Agent OS (通用生产力) |
| License | **MIT** ⭐ | AGPL-3.0 |
| 项目隔离 | 任务级 | **WorkSpace 三层** |
| 记忆 | 黑盒 | 白盒 |
| 主动性 | 用户触发 | **Always-on 24h** |
| Skills | Markdown 脚本 | WorkSpace 装 |
| 国际化 | 中文为主 | 中文为主 |
| 成熟度 | v0.1.0 早期 | 686 commits, 9 人团队 |

**核心优势对比**: BitFun 在 License (MIT) 上明显优于 PilotDeck (AGPL-3.0)，对商业用户更友好。PilotDeck 在项目隔离、记忆管理、主动性上明显领先。

---

## 4. OpenClaw (NousResearch / Peter Steinberger)

### 关键事实
- **首发**: 2026-01-25
- **作者**: Peter Steinberger (奥地利独立开发者，前 PSPDFKit 创始人)
- **Star 增长曲线** (史上最快):
  - 首日: 9,000+
  - 72 小时: 60,000+
  - 1 个月内: 100,000+
  - 3 月: 250,000+
  - 5 月初: 280,000+ (超越 React)
- **代码规模**: 30 万行 TypeScript (个人 + 社区)

### 关键里程碑
- 2026-01-25: 首发 (Clawdbot)
- 商标争议: 改名 Moltbot → 最终定名 OpenClaw
- $CLAWD 代币骗局: 1600 万美元市值后归零
- 2026-02: ClawJacked 漏洞 (CVE 8.8)
- 2026-04-25: v2026.4.24 — DeepSeek V4 Flash 设为新默认模型
- 2026-05-06: v2.18 — ContextEngine + Active Memory 重大更新
- 2026-05-07: v2026.5.7 — 稳定版
- 2026-05-28: 媒体已定性"凉了" (vs PilotDeck 同期爆红)

### 核心能力
- **Local Gateway 架构**: 本地 Node.js 服务 + 消息应用桥接
- **多平台接入**: WhatsApp / Telegram / Discord / Slack / Signal / iMessage
- **心跳系统**: Cron 定时主动推送
- **BYO-Key 模式**: 模型无关 (OpenAI / Anthropic / Ollama 本地模型)
- **Skills 生态**: AgentSkills 插件系统
- **v2.18 升级**: ContextEngine 分层压缩 (62% → 89%)、Active Memory (31M 评分模型)、OTEL 全链路追踪

### 安全风险
- ClawJacked CVE 8.8 (已修复)
- $CLAWD 加密骗局
- 完整系统访问权限 = 巨大攻击面

### 与 PilotDeck 对比
| 维度 | OpenClaw | PilotDeck |
|------|----------|-----------|
| 规模 | 280k stars, 30 万行代码 | 2.6k stars, 686 commits |
| 定位 | 通用 Agent (聊天+执行) | 生产力 OS (项目级) |
| 接入 | 消息应用 (WhatsApp 等) | Web/桌面/CLI/IM (飞书/企微) |
| 项目隔离 | 无 WorkSpace 概念 | **WorkSpace 三层** |
| 记忆 | 本地 Markdown 文件 | **白盒 + Dream + Rollback** |
| 路由 | 无 | **子 Agent 智能路由** |
| 主动性 | Cron 心跳 | **Always-on + 主动发现** |
| Skills | Skills 生态 | WorkSpace 装 |
| 风险 | 全系统访问、ClawJacked | AGPL-3.0、商业风险 |
| 现状 | 进入"工程化稳定期"，媒体定"凉了" | 媒体爆红中 |

**PilotDeck 优势**: 项目隔离、记忆白盒、智能路由 (PilotDeck 三件套独此一家)  
**OpenClaw 优势**: 规模、生态成熟度、Cron 心跳

---

## 5. 国内其他玩家

### 阿里 QoderWork
- 2026-01-30 消息
- 桌面 Agent 工具，一句话调用授权本地应用
- 截至 2026-06 公开信息极少

### MiniMax Agent 桌面版
- 2026-02-03 上线
- 接管本地环境，操作文件 + 软件 + 长期记忆
- 网页端新增 Expert 功能 (可复用模板)

### 阶跃 AI 桌面伙伴
- 2025-09 较早发布
- 本地化任务执行，主打"主动提供服务"

### QClaw (腾讯包装版 OpenClaw)
- 原生支持: 微信 / QQ / MCP / Skills Store / 本地模型 / 多平台通信
- 借助腾讯 IM 生态抢占 Agent 入口

---

## 战略对比矩阵

| 维度 | PilotDeck | Claude Cowork | Skywork | BitFun CoWork | OpenClaw |
|------|-----------|---------------|---------|---------------|----------|
| 平台覆盖 | ⭐⭐⭐⭐⭐ | ⭐⭐ (仅 macOS) | ⭐⭐⭐ (Windows) | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| 项目隔离 | ⭐⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐ | ⭐⭐ | ⭐ |
| 白盒记忆 | ⭐⭐⭐⭐⭐ | ⭐ | ⭐ | ⭐ | ⭐⭐ (本地 MD) |
| 智能路由 | ⭐⭐⭐⭐⭐ | ⭐ | ⭐⭐⭐ (auto) | ⭐ | ⭐ |
| 主动性 | ⭐⭐⭐⭐⭐ | ⭐⭐ | ⭐ | ⭐ | ⭐⭐⭐⭐ (心跳) |
| Skills 生态 | ⭐⭐ | ⭐⭐⭐⭐⭐ (18 插件) | ⭐⭐⭐⭐ (100+) | ⭐⭐ | ⭐⭐⭐ (AgentSkills) |
| MCP 支持 | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |
| 国际化 | ⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐⭐⭐ |
| 文档完善度 | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐⭐ |
| License 友好 | ⭐⭐ (AGPL) | ⭐⭐⭐⭐ (闭源订阅) | ⭐⭐⭐ (闭源订阅) | ⭐⭐⭐⭐⭐ (MIT) | ⭐⭐⭐ |
| 社区规模 | ⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐ | ⭐⭐⭐⭐⭐ |
| 商业化成熟 | ⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐ | ⭐⭐⭐ |

## 对 PilotDeck 的启示

### 优势要保持
1. **WorkSpace 三层隔离** — 全行业独此一家，继续做深
2. **白盒记忆 + Dream** — 唯一可编辑可回滚的产品
3. **子 Agent 智能路由** — 有公开 benchmark 数据支撑
4. **Always-on** — Cron 心跳 OpenClaw 也有，但 PilotDeck 集成更深

### 短板要补
1. **Skills 生态** — 急需 WorkSpace 级 Skills Marketplace
2. **License** — AGPL-3.0 限制企业采用，需提供商业 License 路径
3. **国际化** — 文档以中文为主，海外开发者上手门槛
4. **无正式 Release** — Tags = 0，企业部署缺少版本锚点

### 战略机会
1. **国内差异化**: 火山方舟集成 + 中文文档 + 清华/面壁背书 = 护城河
2. **MCP 深度**: 借 Anthropic 把 MCP 推成标准的东风
3. **多模型协同**: 比 Skywork 三模型更灵活的子 Agent 路由
4. **本地优先**: 数据敏感场景下唯一 WorkSpace 级方案

### 战略威胁
1. **Claude Cowork 跟进**: 如果 Anthropic 推出 Windows 版本 + 加上项目隔离，将是巨大威胁
2. **OpenClaw 回归**: 一旦 OpenClaw 解决 ClawJacked 信任问题，规模优势仍在
3. **Skywork 进化**: 昆仑万维资源充足，3-6 个月内可能跟进 WorkSpace 概念
4. **国内大厂**: 阿里 QoderWork、字节、腾讯 QClaw 一旦发力，个人/小团队项目难以抗衡
