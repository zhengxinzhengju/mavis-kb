# PilotDeck 项目档案

> 最后更新：2026-06-01 17:43 (Asia/Shanghai)  
> 追踪者：Mavis (root session 404453968618295)  
> 数据源：GitHub REST API (2026-06-01 17:43 拉取)

## 一句话定位

**Task-oriented AI Agent productivity platform**——以 WorkSpace 为核心的多项目并行长周期 Agent 操作系统。

> 副标语：**"Pilot Every Agent from One Deck"** ——从一个桌面就能指挥所有 AI 智能体

## 联合开发方

| 角色 | 团队 | 备注 |
|------|------|------|
| 学术 | 清华大学 THUNLP 实验室 | 研究方向 |
| 商业 | ModelBest (面壁智能) | 商业化落地，VoxCPM 语音模型支持 |
| 平台 | OpenBMB | 开源平台 |
| 工程 | AI9Stars | 工程实现 |

## 核心能力 (4 大支柱)

| 能力 | 一句话描述 | 关键特性 |
|------|-----------|---------|
| **WorkSpace** | 项目级"工作舱"——独立 FS + 独立 Memory + 独立 Skills | 物理隔离、范围受限检索、技能自然累积、双轨记忆(Project Memory + Collaboration Feedback) |
| **Smart Router** | 智能任务路由——子 Agent 级别而非 request 级别 | 子任务分配模型，不打断 KV-cache；自然语言自定义规则；任务难度三档(简单/中等/复杂)；可省 70-87% Token |
| **Memory (白盒)** | 记忆可检查、可修改、可回滚 | 全链路可见 + Dream Mode 自动整理 + 一键回滚 |
| **Always-on** | Agent 24 小时常驻 | 主动扫描任务、自主推进、长周期任务支撑 |

## 技术架构（从源码目录提取）

```
src/
├── agent/            # Agent 核心：loop, runtime, session, sub-agent
├── always-on/        # Always-on 后台执行：runtime, protocol, workspace
├── context/          # 上下文管理：memory, compaction, budget, recovery
│   ├── memory/       # 白盒记忆实现
│   ├── compaction/   # 记忆压缩（Dream Mode 核心）
│   └── budget/       # 上下文预算管理
├── router/           # 智能路由：orchestrate, scenario, tokenSaver, stats
│   ├── orchestrate/  # 主副 Agent 编排
│   └── tokenSaver/   # Token 节省策略
├── mcp/              # MCP 协议：client, runtime, protocol
├── gateway/          # API 网关
├── extension/        # 插件系统
├── lifecycle/        # 生命周期管理
├── permission/       # 权限控制
├── tool/             # 工具接口
├── session/          # 会话管理
├── task/             # 任务系统
├── adapters/         # 前端适配器（Web/CLI/IM）
├── pilot/            # Pilot 核心
├── cli/              # 命令行接口
├── cron/             # 定时任务
├── model/            # 模型抽象层
├── web/              # Web 服务
├── ui/               # 前端（React + Vite + Tailwind + shadcn/ui）
└── skills/           # 内建技能（skill-creator, find-skills）
```

## 部署形态

- **Web UI**: 浏览器访问 `http://localhost:3001`
- **桌面应用**: macOS (Apple Silicon) / Windows (x64 / ARM64) 都有预构建安装包
- **命令行**: CLI
- **IM 适配**: 飞书 / 企业微信（通过 `adapters/` 层）

## 安装方式

1. **一键安装** (macOS / Linux): `curl -fsSL https://raw.githubusercontent.com/OpenBMB/PilotDeck/main/install.sh | bash`
2. **源码构建**: `git clone && npm install`
3. **Docker Compose**: `docker compose up -d`

## 模型支持

OpenAI 兼容端点，包括但不限于：
- OpenAI / Anthropic
- DeepSeek / Qwen / Kimi / MiniMax
- 火山方舟 (Volcano Ark) — 2026-05-29 通过 PR #76 集成

## 关键数据（2026-06-01 GitHub API 实时拉取）

| 指标 | 数值 | 备注 |
|------|------|------|
| GitHub Stars | 2,648 | 10 天内 0 → 2.6k |
| Forks | 246 | |
| Open Issues | 3 | #93 #82 #78 |
| Open PRs | 17 | |
| Contributors | 8 (含 1 bot) | 9 人含 cursoragent 团队账号 |
| 总 Commits | 686 | |
| License | AGPL-3.0 | ⚠️ 商业使用需注意 |
| 仓库创建 | 2026-05-22 | 10 天前 |
| 最近 push | 2026-06-01 03:49 UTC | 今天 |
| 最近 commit | 2026-05-29 09:34 UTC | PR #76 合并 |
| Tags / Releases | 0 | ⚠️ 暂无正式 Release |
| 主语言 | TypeScript | 69.9% |
| Size | 18.8 MB | |

## 贡献者排行（截至 2026-06-01）

| 排名 | 用户 | 提交数 | 角色推断 |
|------|------|-------|---------|
| 1 | Mingwwww | 196 | 核心维护者，OpenAI 集成 / Settings |
| 2 | Kaguya-19 | 188 | 核心维护者，Docker / Settings |
| 3 | Gucc111 | 167 | 核心维护者 |
| 4 | mmrdmn | 52 | Installer / Skills |
| 5 | zhengdaqi | 29 | UI / Electron |
| 6 | xhd0728 | 12 | |
| 7 | dependabot[bot] | 8 | 依赖自动更新 |
| 8 | mssssss123 | 5 | Project Settings |

## 已发布版本（源码 tag 视角）

虽然 GitHub Releases 为 0，但根据媒体报道：
- v0.0.9 — 2026-05-25
- v0.0.10 — 2026-05-26
- v0.0.11 — 2026-05-27

说明：团队在密集迭代，但还没打 git tag / 发 GitHub Release。

## 核心性能指标（官方公开测试）

| 场景 | 不开路由 | 开路由 | 节省 |
|------|---------|-------|------|
| 程序员性格测试 | $10.97 | $1.42 | ~87% |
| 社交媒体内容生成 | $12.58 | $2.83 | ~77% |
| 复杂任务（播客/金融/代码） | $18.36 | $3.15 | ~83% |

路由得分对比：Sonnet 4.6 单体 69.1 分 vs Sonnet 4.6 + MiniMax-M2.7 双模型 70.6 分 —— **多模型组合得分反而更高**。

## 目标用户

- 多 Agent 项目的科研/工程团队
- 知识工作者（白皮书、报告、剧本创作）
- 移动/AR 小游戏开发者
- 多语言社交媒体运营
- AI 工程平台搭建者
- 成本敏感的 AI 创业团队

## 已验证的应用场景

1. **模拟经营游戏开发** — 奶茶店游戏（设计 + UI + 玩法）
2. **数据可视化大屏** — 全球 AI 公司融资数据
3. **多语种播客生成** — 联动 VoxCPM 端侧模型，30 种语言
4. **长周期内容创作** — 白皮书、行业报告
5. **手机陀螺仪小游戏** — 端侧模型自动生成
6. **3D 开放世界** — 一天做出本地可跑的"塞尔达式"3D 世界
7. **AI 模型训练流程自动化** — 后台持续运行

## 风险与不确定性

- **License**: AGPL-3.0 对商业产品集成不友好，可能限制企业采用
- **生态早期**: 起步阶段，第三方 Skills / Plugin 不多
- **依赖清华团队节奏**: 核心 3 人贡献了 551/686 (80%) commits，单点风险
- **版本节奏快但不稳**: 3 天连发 3 个版本，API 可能还不稳定
- **国际化**: 文档以中文为主，海外开发者上手门槛
- **暂无正式 Release**: GitHub Tags = 0，企业部署缺少版本锚点

## 更新规则

- **每周一 (周报触发时)**: 拉取 GitHub 指标、commit、PR 数据，刷新本文件
- **每月最后一日 (月报触发时)**: 重点章节（核心能力 + 技术栈）做版本对比，输出演进路线
- **重大事件**: 立即追加到 `timeline.md`，并视情况触发即时简报
