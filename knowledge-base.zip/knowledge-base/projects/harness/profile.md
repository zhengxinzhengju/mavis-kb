# Harness 项目档案

> 最后更新：2026-06-02 10:10 (Asia/Shanghai)  
> 追踪者：Mavis  
> 数据源：GitHub REST API + 媒体资料

## 一句话定位

Open Source DevOps Platform (原 Gitness) - Drone 团队打造的 All-in-One 平台

## 项目元数据

| 字段 | 值 |
|------|-----|
| 项目 ID | `harness` |
| 名称 | Harness |
| 厂商 | Harness Inc. (Jyoti Bansal) |
| 类别 | DevOps Platform |
| License | Apache-2.0 |
| 主语言 | Go |
| 官网 | https://harness.io (商业) / https://github.com/harness/harness (开源) |
| 仓库 | [https://github.com/harness/harness](https://github.com/harness/harness) |

## 关键数据（2026-06-02 实时）

| Stars | **36,297** |
| Forks | 3,180 |
| Watchers | 36,297 |
| Open Issues | 95 |
| License | Apache-2.0 |
| 主语言 | Go |
| Size | 57.8 MB |
| 仓库创建 | 2014-02-07 |
| 最近 push | 2026-06-01 |
| Homepage | https://www.harness.io/open-source |

## 核心能力

- **源码托管** - 源码托管 (Git SCM)
- **CI/CD 流水线** - CI/CD 流水线
- **Gitspaces** - Gitspaces (托管开发环境, 类 Vercel 预览)
- **Artifact Registry** - Artifact Registry (制品注册表)
- **API + CLI 驱动** - API + CLI 驱动
- **Docker 一键启动** - Docker 一键启动
- **Drone 的超级进化版** - Drone 的超级进化版

## 监控优先级

### 高优先级
- 社区采纳度
- Harness 商业版与开源版功能差异

### 中优先级
- CI/CD 性能
- Gitspaces 体验
- Artifact Registry 兼容性

### 低优先级
- Git 性能
- Web UI 体验

## T1 竞品（参考）

(无直接对标，T2 框架相关)

## 更新规则

- 每周一 (周报触发时): 拉取 GitHub 指标、commit、PR 数据，刷新本文件
- 每月最后一日 (月报触发时): 重点章节做版本对比，输出演进路线
- 重大事件: 立即追加到 `timeline.md`
