# OpenHuman 项目档案

> 最后更新：2026-06-02 10:10 (Asia/Shanghai)  
> 追踪者：Mavis  
> 数据源：GitHub REST API + 媒体资料

## 一句话定位

Personal AI Super Intelligence - 分钟级建立上下文的本地 AI 分身

## 项目元数据

| 字段 | 值 |
|------|-----|
| 项目 ID | `openhuman` |
| 名称 | OpenHuman |
| 厂商 | Tiny Humans AI |
| 类别 | Personal Desktop Agent |
| License | GPL-3.0 |
| 主语言 | Rust (~70%) + TypeScript (~26%) |
| 官网 | https://openhuman.ai (推测) |
| 仓库 | [https://github.com/tinyhumansai/openhuman](https://github.com/tinyhumansai/openhuman) |

## 关键数据（2026-06-02 实时）

| Stars | **30,310** |
| Forks | 2,890 |
| Watchers | 30,310 |
| Open Issues | 142 |
| License | GPL-3.0 |
| 主语言 | Rust |
| Size | 99.4 MB |
| 仓库创建 | 2026-02-18 |
| 最近 push | 2026-06-02 |
| Homepage | https://tinyhumans.ai/openhuman |

## 核心能力

- **118+ 第三方集成** - 118+ 第三方集成 (Gmail/Notion/GitHub/Slack/Calendar/Jira/Linear/Stripe)
- **Memory Tree 持久化知识图谱** - Memory Tree 持久化知识图谱 (本地 SQLite + Obsidian 兼容)
- **TokenJuice 压缩** - TokenJuice 压缩 (减少 80% Token)
- **Realtime Mascot** - Realtime Mascot (可加入 Google Meet 会议)
- **潜意识循环 + 做梦机制** - 潜意识循环 + 做梦机制
- **Rust 70% + TypeScript 26% 性能优** - Rust 70% + TypeScript 26% 性能优
- **本地优先 + 端到端加密** - 本地优先 + 端到端加密
- **v0.54+ 已发布 31+ 版本** - v0.54+ 已发布 31+ 版本

## 监控优先级

### 高优先级
- GPL-3.0 商业采用影响
- 118+ 集成稳定性
- Memory Tree 可用性

### 中优先级
- Mascot 多模态体验
- TokenJuice 压缩效果
- v0.x 稳定化

### 低优先级
- GitHub 30k stars 增长曲线

## T1 竞品（参考）

openclaw, pilotdeck, deer-flow, hermes-agent, qwenpaw

## 更新规则

- 每周一 (周报触发时): 拉取 GitHub 指标、commit、PR 数据，刷新本文件
- 每月最后一日 (月报触发时): 重点章节做版本对比，输出演进路线
- 重大事件: 立即追加到 `timeline.md`
